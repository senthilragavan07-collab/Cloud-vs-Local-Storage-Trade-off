package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.models.StorageMode
import com.example.ui.screens.AnalysisScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.AnalysisViewModel
import com.example.viewmodel.ChatViewModel

sealed class Screen {
    data object Splash : Screen()
    data object Home : Screen()
    data class Chat(val mode: StorageMode) : Screen()
    data class Analysis(val returnToChat: Boolean = false) : Screen()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ChatStorageApp()
                }
            }
        }
    }
}

@Composable
fun ChatStorageApp(
    chatViewModel: ChatViewModel = viewModel(),
    analysisViewModel: AnalysisViewModel = viewModel()
) {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Splash) }

    AnimatedContent(
        targetState = currentScreen,
        transitionSpec = {
            fadeIn() + slideInHorizontally { it / 4 } togetherWith
                    fadeOut() + slideOutHorizontally { -it / 4 }
        },
        label = "screen_transition"
    ) { screen ->
        when (screen) {
            is Screen.Splash -> {
                SplashScreen(
                    onNavigateToHome = {
                        currentScreen = Screen.Home
                    }
                )
            }

            is Screen.Home -> {
                HomeScreen(
                    onSelectMode = { mode ->
                        chatViewModel.switchMode(mode)
                        currentScreen = Screen.Chat(mode)
                    },
                    onNavigateToAnalysis = {
                        currentScreen = Screen.Analysis(returnToChat = false)
                    }
                )
            }

            is Screen.Chat -> {
                BackHandler {
                    currentScreen = Screen.Home
                }
                ChatScreen(
                    viewModel = chatViewModel,
                    onNavigateBack = {
                        currentScreen = Screen.Home
                    },
                    onNavigateToAnalysis = {
                        currentScreen = Screen.Analysis(returnToChat = true)
                    }
                )
            }

            is Screen.Analysis -> {
                BackHandler {
                    currentScreen = if (screen.returnToChat) {
                        Screen.Chat(chatViewModel.uiState.value.activeMode)
                    } else {
                        Screen.Home
                    }
                }
                AnalysisScreen(
                    viewModel = analysisViewModel,
                    onNavigateBack = {
                        currentScreen = if (screen.returnToChat) {
                            Screen.Chat(chatViewModel.uiState.value.activeMode)
                        } else {
                            Screen.Home
                        }
                    }
                )
            }
        }
    }
}
