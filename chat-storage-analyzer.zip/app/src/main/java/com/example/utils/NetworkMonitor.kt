package com.example.utils

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class NetworkMonitor(context: Context) {
    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager

    private val _isSystemOnline = MutableStateFlow(checkInitialConnectivity())
    private val _isSimulatedOffline = MutableStateFlow(false)

    private val _effectiveOnline = MutableStateFlow(checkInitialConnectivity())
    val isOnline: StateFlow<Boolean> = _effectiveOnline.asStateFlow()

    init {
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        connectivityManager?.registerNetworkCallback(
            request,
            object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    _isSystemOnline.value = true
                    updateEffectiveState()
                }

                override fun onLost(network: Network) {
                    _isSystemOnline.value = false
                    updateEffectiveState()
                }
            }
        )
    }

    private fun checkInitialConnectivity(): Boolean {
        val cm = connectivityManager ?: return true
        val activeNetwork = cm.activeNetwork ?: return true // Default optimistic
        val capabilities = cm.getNetworkCapabilities(activeNetwork) ?: return true
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun setSimulatedOffline(offline: Boolean) {
        _isSimulatedOffline.value = offline
        updateEffectiveState()
    }

    fun isSimulatedOffline(): Boolean = _isSimulatedOffline.value

    private fun updateEffectiveState() {
        val effective = _isSystemOnline.value && !_isSimulatedOffline.value
        _effectiveOnline.value = effective
    }
}
