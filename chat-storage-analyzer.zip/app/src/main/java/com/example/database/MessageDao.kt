package com.example.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessages(messages: List<MessageEntity>)

    @Query("SELECT * FROM messages ORDER BY timestampLong ASC")
    fun getMessages(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE storageMode = :mode ORDER BY timestampLong ASC")
    fun getMessagesByMode(mode: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages ORDER BY timestampLong ASC")
    suspend fun getAllMessagesSync(): List<MessageEntity>

    @Query("SELECT * FROM messages WHERE storageMode = :mode ORDER BY timestampLong ASC")
    suspend fun getMessagesByModeSync(mode: String): List<MessageEntity>

    @Query("SELECT * FROM messages WHERE storageMode = 'HYBRID' AND isSyncedToCloud = 0 ORDER BY timestampLong ASC")
    suspend fun getUnsyncedMessages(): List<MessageEntity>

    @Query("UPDATE messages SET isSyncedToCloud = 1, firestoreDocId = :firestoreId, syncLatencyMs = :syncTimeMs WHERE id = :id")
    suspend fun markAsSynced(id: Long, firestoreId: String, syncTimeMs: Long)

    @Query("DELETE FROM messages WHERE id = :id")
    suspend fun deleteMessage(id: Long)

    @Query("DELETE FROM messages WHERE storageMode = :mode")
    suspend fun deleteMessagesByMode(mode: String)

    @Query("DELETE FROM messages")
    suspend fun deleteAllMessages()

    @Query("SELECT COUNT(*) FROM messages")
    suspend fun getMessageCount(): Int

    @Query("SELECT COUNT(*) FROM messages WHERE storageMode = :mode")
    suspend fun getMessageCountByMode(mode: String): Int
}
