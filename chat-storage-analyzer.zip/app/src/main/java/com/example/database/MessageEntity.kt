package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.models.ChatMessage
import com.example.models.StorageMode
import com.example.utils.TimeUtils

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sender: String,
    val message: String,
    val timestamp: String,
    val timestampLong: Long = System.currentTimeMillis(),
    val storageMode: String = "SQLITE",
    val writeLatencyMs: Long = 0,
    val readLatencyMs: Long = 0,
    val isSyncedToCloud: Boolean = false,
    val syncLatencyMs: Long = 0,
    val firestoreDocId: String? = null
) {
    fun toChatMessage(): ChatMessage {
        val mode = try {
            StorageMode.valueOf(storageMode)
        } catch (_: Exception) {
            StorageMode.SQLITE
        }
        return ChatMessage(
            id = id,
            firestoreId = firestoreDocId ?: "",
            sender = sender,
            message = message,
            timestamp = timestampLong,
            formattedTime = timestamp.ifEmpty { TimeUtils.formatTime(timestampLong) },
            storageMode = mode,
            writeLatencyMs = writeLatencyMs,
            readLatencyMs = readLatencyMs,
            isSyncedToCloud = isSyncedToCloud,
            syncLatencyMs = syncLatencyMs,
            isOfflineCreated = !isSyncedToCloud && mode == StorageMode.HYBRID
        )
    }

    companion object {
        fun fromChatMessage(chatMessage: ChatMessage): MessageEntity {
            return MessageEntity(
                id = chatMessage.id,
                sender = chatMessage.sender,
                message = chatMessage.message,
                timestamp = chatMessage.formattedTime.ifEmpty { TimeUtils.formatTime(chatMessage.timestamp) },
                timestampLong = chatMessage.timestamp,
                storageMode = chatMessage.storageMode.name,
                writeLatencyMs = chatMessage.writeLatencyMs,
                readLatencyMs = chatMessage.readLatencyMs,
                isSyncedToCloud = chatMessage.isSyncedToCloud,
                syncLatencyMs = chatMessage.syncLatencyMs,
                firestoreDocId = chatMessage.firestoreId.ifEmpty { null }
            )
        }
    }
}
