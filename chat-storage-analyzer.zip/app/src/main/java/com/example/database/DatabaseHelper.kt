package com.example.database

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.models.ChatMessage
import com.example.models.StorageMode
import com.example.utils.TimeUtils

class DatabaseHelper(context: Context) : SQLiteOpenHelper(
    context.applicationContext,
    DATABASE_NAME,
    null,
    DATABASE_VERSION
) {
    companion object {
        const val DATABASE_NAME = "chat_sqlite_native.db"
        const val DATABASE_VERSION = 1
        const val TABLE_MESSAGES = "messages"

        const val COLUMN_ID = "id"
        const val COLUMN_SENDER = "sender"
        const val COLUMN_MESSAGE = "message"
        const val COLUMN_TIMESTAMP = "timestamp"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTableQuery = """
            CREATE TABLE $TABLE_MESSAGES (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_SENDER TEXT NOT NULL,
                $COLUMN_MESSAGE TEXT NOT NULL,
                $COLUMN_TIMESTAMP TEXT NOT NULL
            )
        """.trimIndent()
        db.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_MESSAGES")
        onCreate(db)
    }

    /**
     * Inserts a chat message into SQLite and returns the inserted row ID.
     */
    fun insertMessage(sender: String, message: String, timestamp: String): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_SENDER, sender)
            put(COLUMN_MESSAGE, message)
            put(COLUMN_TIMESTAMP, timestamp)
        }
        return db.insert(TABLE_MESSAGES, null, values)
    }

    /**
     * Retrieves all chat messages from SQLite ordered by ID ascending.
     */
    fun getMessages(): List<ChatMessage> {
        val messages = mutableListOf<ChatMessage>()
        val db = readableDatabase
        val cursor: Cursor? = db.query(
            TABLE_MESSAGES,
            arrayOf(COLUMN_ID, COLUMN_SENDER, COLUMN_MESSAGE, COLUMN_TIMESTAMP),
            null,
            null,
            null,
            null,
            "$COLUMN_ID ASC"
        )

        cursor?.use {
            val idIndex = it.getColumnIndexOrThrow(COLUMN_ID)
            val senderIndex = it.getColumnIndexOrThrow(COLUMN_SENDER)
            val messageIndex = it.getColumnIndexOrThrow(COLUMN_MESSAGE)
            val timestampIndex = it.getColumnIndexOrThrow(COLUMN_TIMESTAMP)

            while (it.moveToNext()) {
                val id = it.getLong(idIndex)
                val sender = it.getString(senderIndex)
                val text = it.getString(messageIndex)
                val time = it.getString(timestampIndex)

                messages.add(
                    ChatMessage(
                        id = id,
                        sender = sender,
                        message = text,
                        formattedTime = time,
                        storageMode = StorageMode.SQLITE
                    )
                )
            }
        }
        return messages
    }

    /**
     * Deletes a message by its ID.
     */
    fun deleteMessage(id: Long): Int {
        val db = writableDatabase
        return db.delete(TABLE_MESSAGES, "$COLUMN_ID = ?", arrayOf(id.toString()))
    }

    /**
     * Deletes all messages.
     */
    fun deleteAllMessages(): Int {
        val db = writableDatabase
        return db.delete(TABLE_MESSAGES, null, null)
    }
}
