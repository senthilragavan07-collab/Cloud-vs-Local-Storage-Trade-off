package com.example.models

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.FirestoreOrange
import com.example.ui.theme.HybridViolet
import com.example.ui.theme.SqliteGreen

enum class StorageMode(
    val title: String,
    val subtitle: String,
    val description: String,
    val brandColor: Color,
    val tag: String
) {
    SQLITE(
        title = "SQLite (Local Storage)",
        subtitle = "Zero-network instant disk persistence",
        description = "Stores all chat messages locally in the device's embedded relational SQLite database. Offers ultra-low latency, zero data usage, and works offline.",
        brandColor = SqliteGreen,
        tag = "SQLITE"
    ),
    FIRESTORE(
        title = "Firestore (Cloud Storage)",
        subtitle = "Real-time multi-client cloud database",
        description = "Stores messages on Google Cloud Firestore with real-time synchronization, multi-device access, and scalable cloud backups.",
        brandColor = FirestoreOrange,
        tag = "FIRESTORE"
    ),
    HYBRID(
        title = "Hybrid Mode (SQLite + Firestore)",
        subtitle = "Local-first speed + Cloud sync",
        description = "Writes immediately to SQLite for instant sub-5ms UI responsiveness, then asynchronously syncs to Firestore when internet is available.",
        brandColor = HybridViolet,
        tag = "HYBRID"
    )
}
