package com.example.models

data class ChatMessage(
    val id: Long = 0,
    val firestoreId: String = "",
    val sender: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val formattedTime: String = "",
    val storageMode: StorageMode,
    val writeLatencyMs: Long = 0,
    val readLatencyMs: Long = 0,
    val isSyncedToCloud: Boolean = false,
    val syncLatencyMs: Long = 0,
    val isOfflineCreated: Boolean = false
)
