package com.example.models

data class BenchmarkResult(
    val mode: StorageMode,
    val count: Int,
    val totalWriteTimeMs: Long,
    val avgWriteTimeMs: Double,
    val minWriteTimeMs: Long,
    val maxWriteTimeMs: Long,
    val totalReadTimeMs: Long,
    val avgReadTimeMs: Double,
    val minReadTimeMs: Long,
    val maxReadTimeMs: Long,
    val timestamp: Long = System.currentTimeMillis()
)

data class StorageMetrics(
    val sqliteAvgWriteMs: Double = 0.0,
    val sqliteAvgReadMs: Double = 0.0,
    val sqliteMessageCount: Int = 0,
    val firestoreAvgWriteMs: Double = 0.0,
    val firestoreAvgReadMs: Double = 0.0,
    val firestoreMessageCount: Int = 0,
    val hybridAvgWriteMs: Double = 0.0,
    val hybridAvgSyncMs: Double = 0.0,
    val hybridMessageCount: Int = 0,
    val syncedToCloudCount: Int = 0,
    val pendingCloudSyncCount: Int = 0
)
