package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.models.ChatMessage
import com.example.models.StorageMode
import com.example.repository.ChatRepository
import com.example.utils.NetworkMonitor
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ChatUiState(
    val activeMode: StorageMode = StorageMode.SQLITE,
    val currentSender: String = "Alice",
    val isOnline: Boolean = true,
    val isSimulatedOffline: Boolean = false,
    val lastLatencyMs: Long = 0L,
    val isSending: Boolean = false,
    val isSyncing: Boolean = false,
    val pendingSyncCount: Int = 0,
    val bannerMessage: String? = null
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    val networkMonitor = NetworkMonitor(application)
    val repository = ChatRepository(application, networkMonitor)

    private val _uiState = MutableStateFlow(ChatUiState(isOnline = networkMonitor.isOnline.value))
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private var messageCollectionJob: Job? = null

    init {
        switchMode(StorageMode.SQLITE)

        // Observe network state
        viewModelScope.launch {
            networkMonitor.isOnline.collect { online ->
                val wasOffline = !_uiState.value.isOnline
                _uiState.value = _uiState.value.copy(
                    isOnline = online,
                    isSimulatedOffline = networkMonitor.isSimulatedOffline()
                )
                // If we returned online, automatically trigger hybrid sync!
                if (wasOffline && online && _uiState.value.activeMode == StorageMode.HYBRID) {
                    syncHybridMessages()
                }
            }
        }

        // Track repository latency
        viewModelScope.launch {
            repository.lastOperationLatency.collect { latency ->
                if (latency > 0) {
                    _uiState.value = _uiState.value.copy(lastLatencyMs = latency)
                }
            }
        }

        // Periodic check for unsynced count
        viewModelScope.launch {
            while (true) {
                repository.updateMetrics()
                delay(3000)
            }
        }
    }

    fun switchMode(mode: StorageMode) {
        _uiState.value = _uiState.value.copy(activeMode = mode)
        messageCollectionJob?.cancel()
        messageCollectionJob = viewModelScope.launch {
            repository.getMessagesForMode(mode).collect { list ->
                _messages.value = list
            }
        }
    }

    fun toggleSender() {
        val next = if (_uiState.value.currentSender == "Alice") "Bob" else "Alice"
        _uiState.value = _uiState.value.copy(currentSender = next)
    }

    fun toggleSimulatedNetwork(isOffline: Boolean) {
        networkMonitor.setSimulatedOffline(isOffline)
        repository.firestoreManager.setSimulatedNetworkOffline(isOffline)
        _uiState.value = _uiState.value.copy(
            isSimulatedOffline = isOffline,
            isOnline = networkMonitor.isOnline.value,
            bannerMessage = if (isOffline) "⚠️ Network Simulation: OFFLINE mode enabled" else "✅ Network Simulation: ONLINE restored"
        )
    }

    fun clearBanner() {
        _uiState.value = _uiState.value.copy(bannerMessage = null)
    }

    fun sendMessage(text: String) {
        if (text.isBlank()) return
        val currentMode = _uiState.value.activeMode
        val sender = _uiState.value.currentSender

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSending = true)
            try {
                val sent = repository.sendMessage(sender, text.trim(), currentMode)
                _uiState.value = _uiState.value.copy(
                    lastLatencyMs = sent.writeLatencyMs,
                    bannerMessage = when (currentMode) {
                        StorageMode.SQLITE -> "⚡ SQLite write: ${sent.writeLatencyMs}ms"
                        StorageMode.FIRESTORE -> "☁️ Firestore write: ${sent.writeLatencyMs}ms"
                        StorageMode.HYBRID -> if (sent.isSyncedToCloud) {
                            "⚡ Local: ${sent.writeLatencyMs}ms • ☁️ Synced: ${sent.syncLatencyMs}ms"
                        } else {
                            "⚡ Saved locally (${sent.writeLatencyMs}ms) • ⏳ Pending sync"
                        }
                    }
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    bannerMessage = "Error: ${e.message}"
                )
            } finally {
                _uiState.value = _uiState.value.copy(isSending = false)
            }
        }
    }

    fun sendBurstMessages(count: Int) {
        val currentMode = _uiState.value.activeMode
        val sender = _uiState.value.currentSender

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSending = true)
            var totalTime = 0L
            val start = System.currentTimeMillis()
            for (i in 1..count) {
                try {
                    val msg = repository.sendMessage(sender, "Burst test message #$i [$currentMode]", currentMode)
                    totalTime += msg.writeLatencyMs
                } catch (_: Exception) {}
            }
            val totalElapsed = System.currentTimeMillis() - start
            val avg = if (count > 0) totalElapsed / count else 0
            _uiState.value = _uiState.value.copy(
                isSending = false,
                lastLatencyMs = avg,
                bannerMessage = "Burst complete: $count messages sent. Avg latency: ${avg}ms/msg"
            )
        }
    }

    fun syncHybridMessages() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSyncing = true)
            val (syncedCount, syncTime) = repository.syncPendingMessages()
            _uiState.value = _uiState.value.copy(
                isSyncing = false,
                bannerMessage = if (syncedCount > 0) {
                    "☁️ Synchronized $syncedCount pending messages to Firestore in ${syncTime}ms!"
                } else {
                    "All messages already in sync."
                }
            )
        }
    }

    fun clearMessages() {
        viewModelScope.launch {
            repository.clearMessages(_uiState.value.activeMode)
            _uiState.value = _uiState.value.copy(bannerMessage = "Cleared messages for ${_uiState.value.activeMode.title}")
        }
    }
}
