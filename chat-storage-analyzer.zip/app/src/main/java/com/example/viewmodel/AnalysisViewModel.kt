package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.models.BenchmarkResult
import com.example.models.StorageMetrics
import com.example.models.StorageMode
import com.example.repository.ChatRepository
import com.example.utils.NetworkMonitor
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AnalysisUiState(
    val isBenchmarking: Boolean = false,
    val benchmarkProgress: Float = 0f,
    val progressStatus: String = "",
    val sqliteResult: BenchmarkResult? = null,
    val firestoreResult: BenchmarkResult? = null,
    val hybridResult: BenchmarkResult? = null,
    val metrics: StorageMetrics = StorageMetrics()
)

class AnalysisViewModel(application: Application) : AndroidViewModel(application) {
    private val networkMonitor = NetworkMonitor(application)
    private val repository = ChatRepository(application, networkMonitor)

    private val _uiState = MutableStateFlow(AnalysisUiState())
    val uiState: StateFlow<AnalysisUiState> = _uiState.asStateFlow()

    init {
        // Collect repository metrics
        viewModelScope.launch {
            repository.storageMetrics.collect { m ->
                _uiState.value = _uiState.value.copy(metrics = m)
            }
        }
        viewModelScope.launch {
            repository.updateMetrics()
        }
    }

    fun runBenchmarkSuite(count: Int = 20) {
        if (_uiState.value.isBenchmarking) return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isBenchmarking = true,
                benchmarkProgress = 0f,
                progressStatus = "Initializing benchmark with $count payloads..."
            )

            // Step 1: Benchmark SQLite
            _uiState.value = _uiState.value.copy(progressStatus = "Running SQLite benchmark (0/$count)...")
            val sqliteRes = repository.runBenchmark(StorageMode.SQLITE, count) { current, total ->
                val p = (current.toFloat() / total) * 0.33f
                _uiState.value = _uiState.value.copy(
                    benchmarkProgress = p,
                    progressStatus = "Running SQLite benchmark ($current/$total)..."
                )
            }
            _uiState.value = _uiState.value.copy(sqliteResult = sqliteRes)

            // Step 2: Benchmark Firestore
            _uiState.value = _uiState.value.copy(progressStatus = "Running Firestore Cloud benchmark (0/$count)...")
            val firestoreRes = repository.runBenchmark(StorageMode.FIRESTORE, count) { current, total ->
                val p = 0.33f + (current.toFloat() / total) * 0.33f
                _uiState.value = _uiState.value.copy(
                    benchmarkProgress = p,
                    progressStatus = "Running Firestore benchmark ($current/$total)..."
                )
            }
            _uiState.value = _uiState.value.copy(firestoreResult = firestoreRes)

            // Step 3: Benchmark Hybrid
            _uiState.value = _uiState.value.copy(progressStatus = "Running Hybrid Mode benchmark (0/$count)...")
            val hybridRes = repository.runBenchmark(StorageMode.HYBRID, count) { current, total ->
                val p = 0.66f + (current.toFloat() / total) * 0.34f
                _uiState.value = _uiState.value.copy(
                    benchmarkProgress = p,
                    progressStatus = "Running Hybrid benchmark ($current/$total)..."
                )
            }
            _uiState.value = _uiState.value.copy(
                hybridResult = hybridRes,
                isBenchmarking = false,
                benchmarkProgress = 1f,
                progressStatus = "Benchmark completed successfully!"
            )

            repository.updateMetrics()
        }
    }

    fun resetBenchmarks() {
        _uiState.value = _uiState.value.copy(
            sqliteResult = null,
            firestoreResult = null,
            hybridResult = null,
            progressStatus = ""
        )
    }
}
