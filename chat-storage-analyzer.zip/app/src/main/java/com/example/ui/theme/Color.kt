package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate500 = Color(0xFF64748B)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

// Storage Mode Brand Colors
val SqliteGreen = Color(0xFF059669)
val SqliteGreenDark = Color(0xFF10B981)
val SqliteGreenLight = Color(0xFFD1FAE5)

val FirestoreOrange = Color(0xFFEA580C)
val FirestoreOrangeDark = Color(0xFFF97316)
val FirestoreOrangeLight = Color(0xFFFFEDD5)

val HybridViolet = Color(0xFF7C3AED)
val HybridVioletDark = Color(0xFF8B5CF6)
val HybridVioletLight = Color(0xFFEDE9FE)

val SyncSuccessColor = Color(0xFF10B981)
val SyncPendingColor = Color(0xFFF59E0B)
val SyncOfflineColor = Color(0xFFEF4444)

// Material 3 Core
val PrimaryBlue = Color(0xFF2563EB)
val PrimaryBlueLight = Color(0xFF60A5FA)
val SecondaryTeal = Color(0xFF0D9488)
val TertiaryAmber = Color(0xFFD97706)
