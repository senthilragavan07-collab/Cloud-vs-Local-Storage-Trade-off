package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.FirestoreOrange
import com.example.ui.theme.HybridViolet
import com.example.ui.theme.SqliteGreen
import com.example.ui.theme.SyncOfflineColor
import com.example.ui.theme.SyncPendingColor
import com.example.ui.theme.SyncSuccessColor

data class BarChartItem(
    val label: String,
    val writeTimeMs: Double,
    val readTimeMs: Double,
    val color: Color
)

@Composable
fun LatencyBarChart(
    items: List<BarChartItem>,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Latency Comparison (Read vs Write in ms)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Lower value = Faster response time",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Legend
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                LegendItem(color = MaterialTheme.colorScheme.primary, text = "Write Latency")
                LegendItem(color = MaterialTheme.colorScheme.secondary, text = "Read Latency")
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Canvas Bar Chart
            val maxVal = items.flatMap { listOf(it.writeTimeMs, it.readTimeMs) }.maxOrNull()?.coerceAtLeast(10.0) ?: 100.0

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val bottomAxisY = canvasHeight - 24.dp.toPx()
                val chartHeight = bottomAxisY - 10.dp.toPx()

                // Baseline
                drawLine(
                    color = Color.Gray.copy(alpha = 0.4f),
                    start = Offset(0f, bottomAxisY),
                    end = Offset(canvasWidth, bottomAxisY),
                    strokeWidth = 2f
                )

                val groupCount = items.size
                if (groupCount == 0) return@Canvas
                val groupWidth = canvasWidth / groupCount
                val barWidth = 18.dp.toPx()
                val barSpacing = 4.dp.toPx()

                items.forEachIndexed { index, item ->
                    val groupCenterX = (index * groupWidth) + (groupWidth / 2f)

                    // Write Bar
                    val writeHeight = ((item.writeTimeMs / maxVal) * chartHeight).toFloat().coerceAtLeast(4f)
                    val writeLeft = groupCenterX - barWidth - (barSpacing / 2f)
                    val writeTop = bottomAxisY - writeHeight

                    drawRoundRect(
                        color = item.color,
                        topLeft = Offset(writeLeft, writeTop),
                        size = Size(barWidth, writeHeight),
                        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                    )

                    // Read Bar
                    val readHeight = ((item.readTimeMs / maxVal) * chartHeight).toFloat().coerceAtLeast(4f)
                    val readLeft = groupCenterX + (barSpacing / 2f)
                    val readTop = bottomAxisY - readHeight

                    drawRoundRect(
                        color = item.color.copy(alpha = 0.5f),
                        topLeft = Offset(readLeft, readTop),
                        size = Size(barWidth, readHeight),
                        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                    )

                    // Draw values above bars
                    drawContext.canvas.nativeCanvas.apply {
                        val paint = android.graphics.Paint().apply {
                            color = android.graphics.Color.GRAY
                            textSize = 24f
                            textAlign = android.graphics.Paint.Align.CENTER
                            isAntiAlias = true
                        }
                        drawText("${item.writeTimeMs.toInt()}ms", writeLeft + barWidth / 2, writeTop - 6f, paint)

                        val labelPaint = android.graphics.Paint().apply {
                            color = android.graphics.Color.WHITE
                            textSize = 28f
                            textAlign = android.graphics.Paint.Align.CENTER
                            isFakeBoldText = true
                            isAntiAlias = true
                        }
                        drawText(item.label, groupCenterX, canvasHeight - 2f, labelPaint)
                    }
                }
            }
        }
    }
}

@Composable
fun SyncDistributionPieChart(
    syncedCount: Int,
    pendingCount: Int,
    localOnlyCount: Int,
    modifier: Modifier = Modifier
) {
    val total = (syncedCount + pendingCount + localOnlyCount).coerceAtLeast(1)
    val syncedAngle = (syncedCount.toFloat() / total) * 360f
    val pendingAngle = (pendingCount.toFloat() / total) * 360f
    val localAngle = (localOnlyCount.toFloat() / total) * 360f

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Message Distribution & Sync Status",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Breakdown across Cloud, SQLite, and Pending queues",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                // Donut Chart
                Box(
                    modifier = Modifier.size(130.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.size(120.dp)) {
                        val strokeWidth = 24.dp.toPx()
                        var currentStartAngle = -90f

                        // Local Only (Green)
                        if (localOnlyCount > 0 || total == 1) {
                            drawArc(
                                color = SqliteGreen,
                                startAngle = currentStartAngle,
                                sweepAngle = if (syncedCount == 0 && pendingCount == 0 && localOnlyCount == 0) 360f else localAngle,
                                useCenter = false,
                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                            )
                            currentStartAngle += localAngle
                        }

                        // Synced (Orange/Cyan)
                        if (syncedCount > 0) {
                            drawArc(
                                color = SyncSuccessColor,
                                startAngle = currentStartAngle,
                                sweepAngle = syncedAngle,
                                useCenter = false,
                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                            )
                            currentStartAngle += syncedAngle
                        }

                        // Pending (Amber)
                        if (pendingCount > 0) {
                            drawArc(
                                color = SyncPendingColor,
                                startAngle = currentStartAngle,
                                sweepAngle = pendingAngle,
                                useCenter = false,
                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$total",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Msgs",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Legend List
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    LegendItemWithCount(
                        color = SqliteGreen,
                        label = "SQLite Local",
                        count = localOnlyCount,
                        percent = (localOnlyCount * 100 / total)
                    )
                    LegendItemWithCount(
                        color = SyncSuccessColor,
                        label = "Synced to Cloud",
                        count = syncedCount,
                        percent = (syncedCount * 100 / total)
                    )
                    LegendItemWithCount(
                        color = SyncPendingColor,
                        label = "Pending Sync",
                        count = pendingCount,
                        percent = (pendingCount * 100 / total)
                    )
                }
            }
        }
    }
}

@Composable
fun LatencyTrendGraph(
    sqlitePoints: List<Long>,
    firestorePoints: List<Long>,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Performance Curve (Consecutive Operations)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Real-time jitter and network roundtrip variance",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                LegendItem(color = SqliteGreen, text = "SQLite (<5ms flat)")
                LegendItem(color = FirestoreOrange, text = "Firestore (~100ms jitter)")
            }

            Spacer(modifier = Modifier.height(16.dp))

            val maxPoints = maxOf(sqlitePoints.size, firestorePoints.size).coerceAtLeast(5)
            val maxLatency = maxOf(
                sqlitePoints.maxOrNull() ?: 10L,
                firestorePoints.maxOrNull() ?: 150L
            ).toFloat().coerceAtLeast(50f)

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
            ) {
                val w = size.width
                val h = size.height

                // Gridlines
                for (step in 1..3) {
                    val y = h * (step / 4f)
                    drawLine(
                        color = Color.Gray.copy(alpha = 0.2f),
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 1f
                    )
                }

                // SQLite Line
                if (sqlitePoints.isNotEmpty()) {
                    val stepX = w / (sqlitePoints.size - 1).coerceAtLeast(1)
                    val path = Path()
                    sqlitePoints.forEachIndexed { i, pt ->
                        val x = i * stepX
                        val y = h - ((pt / maxLatency) * h).coerceIn(4f, h - 4f)
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(
                        path = path,
                        color = SqliteGreen,
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                    )
                }

                // Firestore Line
                if (firestorePoints.isNotEmpty()) {
                    val stepX = w / (firestorePoints.size - 1).coerceAtLeast(1)
                    val path = Path()
                    firestorePoints.forEachIndexed { i, pt ->
                        val x = i * stepX
                        val y = h - ((pt / maxLatency) * h).coerceIn(4f, h - 4f)
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(
                        path = path,
                        color = FirestoreOrange,
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }
        }
    }
}

@Composable
private fun LegendItem(color: Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .background(color, CircleShape)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(text = text, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun LegendItemWithCount(color: Color, label: String, count: Int, percent: Int) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .background(color, CircleShape)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Column {
            Text(text = label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            Text(
                text = "$count msgs ($percent%)",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
