package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.database.DatabaseHelper
import com.example.models.StorageMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Chat Storage Analyzer", appName)
    }

    @Test
    fun `sqlite database helper inserts and retrieves messages`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val dbHelper = DatabaseHelper(context)
        dbHelper.deleteAllMessages()

        val id = dbHelper.insertMessage("Alice", "Testing SQLite storage latency", "12:00:00")
        assertTrue(id > 0)

        val messages = dbHelper.getMessages()
        assertEquals(1, messages.size)
        assertEquals("Alice", messages[0].sender)
        assertEquals("Testing SQLite storage latency", messages[0].message)
        assertEquals(StorageMode.SQLITE, messages[0].storageMode)

        dbHelper.deleteAllMessages()
        val emptyList = dbHelper.getMessages()
        assertEquals(0, emptyList.size)
    }

    @Test
    fun `storage mode tags and titles`() {
        assertEquals("SQLITE", StorageMode.SQLITE.tag)
        assertEquals("FIRESTORE", StorageMode.FIRESTORE.tag)
        assertEquals("HYBRID", StorageMode.HYBRID.tag)
    }
}
